﻿
(function _init() {
    /**************** 加载时间轴内容相关方法 ****************/
    // 加载年，然后加载月
    function loadTimeHTML() {
        var dc = document.createDocumentFragment();
        for (var y = year; y >= 2008; y--) {
            var li = document.createElement("li");
            var a = Simple.dom.append("a", {}, y, li);
            href_idx[y] = aCount++;
            if (y > 2010) {
                var childUl = document.createElement("ul");
                loadMonth(childUl, y);
                li.appendChild(childUl);
            }
            else {
                a.className = "past";
            }
            dc.appendChild(li);
        }
        ul.appendChild(dc);
    }

    // 加载月
    function loadMonth(childUl, y) {
        var dc = document.createDocumentFragment();
        for (var m = 12; m >= 1; m--) {
            var li = document.createElement("li");
            var mm = Simple.date.transDateString(m);
            var a = Simple.dom.append("a", {}, mm, li);
            if (y == 2011 && m < 8) {
                a.className = "past";
            }
            if (y == year && m > month) {
                a.className = "future";
            }
            href_idx[y + "" + mm] = aCount++;
            dc.appendChild(li);
        }
        childUl.appendChild(dc);
    }
    /**************** 加载时间轴内容相关方法 ****************/

    /**************** 初始化版本号相关方法 ****************/
    function initVersion() {
        // 协议号，此处需要拓展字典
        var range_dic = { "25780-3721": "20110829", "25790-3721": "20110907" };
        var jump_from = Simple.query(window.location.search, "from");
        var jump_to = Simple.query(window.location.search, "to");
        var reg = /^\d+\-\d+$/;
        // 跳转入口为客户端，显示用户当前版本;跳转入口为官网，显示最新版本
        if (reg.test(jump_from) && reg.test(jump_to)) {
            anchor = range_dic[jump_to];
            if (range_dic[jump_from]) {
                initMonth = range_dic[jump_from];
                nYearCurrent = year - parseInt(initMonth.substring(0, 4));
                nMonthCurrent = 12 - parseInt(initMonth.substring(4, 6).replace(/^0/, ""));
            }
        }
    }
    /**************** 初始化版本号相关方法 ****************/

    /**************** 时间轴加载样式相关方法 ****************/
    function loadTimeCss() {
        // 保存年及月索引
        var y = anchor ? anchor.substring(0, 4) : initMonth.substring(0, 4);
        var m = anchor ? anchor.substring(4, 6) : initMonth.substring(4, 6);
        nYearSelected = year - parseInt(y);
        nMonthSelected = 12 - parseInt(m.replace(/^0/, ""));
        // 初始化选择年及月样式
        updateLi({ "index": href_idx[y] }, { "index": href_idx[y + m] }, true);
        // 初始化时间轴位置
        nMove = nYearSelected - 3 < 0 ? 0 : nYearSelected - 3;
        if (nMove > 0) {
            left = -59 * nMove;
            ul.style.marginLeft = left + "px";
        }
        refreshMoveIcon(nMove);
    }

    function leftMove() {
        move(-1);
        refreshMoveIcon(--nMove);
        refreshLiCore();
        refreshBubble();
        pgvSendClick({ hottag: "R1.JT.IM.PLUGIN_YEAR" });
    }

    function rightMove() {
        move(1);
        refreshMoveIcon(++nMove);
        refreshLiCore();
        refreshBubble();
        pgvSendClick({ hottag: "R1.JT.IM.PLUGIN_YEAR" });
    }

    function move(nLeft) {
        var sLeft = Simple("time_nav").style.marginLeft;
        var m = sLeft.match(/(-*\d+)px/);
        m = m ? m[1] : 0;
        var sgn = -Simple.math.sgn(nLeft);
        var inileft = parseInt(m);
        var desLeft = inileft - 59 * nLeft;
        var nDiff = 10 * sgn;
        var nStep = 1;
        var p = setInterval(function () {
            var left = inileft + nDiff * nStep;
            if ((left - desLeft) * sgn > 0) {
                left = desLeft;
                Simple("time_nav").style.marginLeft = left + "px";
                clearInterval(p);
            }
            else {
                Simple("time_nav").style.marginLeft = left + "px";
            }
            nStep++;
        }, 25);
    }

    // 刷新左右移时间轴按钮图标、绑定或解绑点击事件
    function refreshMoveIcon(nMove) {
        if (year <= 2011) {
            Simple("time_left").style.background = "none";
            Simple("time_right").style.background = "none";
            return;
        }
        if (nMove > 0) {
            Simple("time_left").style.backgroundPosition = "0 -34px";
            Simple("time_left").style.cursor = "pointer";
            Simple.e.addEvent(Simple("time_left"), "click", leftMove);
        }
        else {
            Simple("time_left").style.backgroundPosition = "0 -17px";
            Simple("time_left").style.cursor = "";
            Simple.e.removeEvent(Simple("time_left"), "click", leftMove);
        }
        if (nMove < nTotal) {
            Simple("time_right").style.backgroundPosition = "0 -51px";
            Simple("time_right").style.cursor = "pointer";
            Simple.e.addEvent(Simple("time_right"), "click", rightMove);
        }
        else {
            Simple("time_right").style.backgroundPosition = "0 0";
            Simple("time_right").style.cursor = "";
            Simple.e.removeEvent(Simple("time_right"), "click", rightMove);
        }
    }
    /**************** 时间轴加载样式相关方法 ****************/

    /**************** 更新时间轴样式相关方法 ****************/
    function CorrectCss() {
        var selectedYear = year - nYearSelected;
        var selectedMonth = 12 - nMonthSelected;
        // 如果当前选中样式不存在则从anchorDic中拉取，此情况主要是翻月后没有当月版本所致
        // 因为页面最开始会默认选中一个，主要是从视觉上考虑，等很长时间时间轴都不加载会很难看
        var href = selectedYear + Simple.date.transDateString(selectedMonth);
        if (!anchorDic[href]) {
            for (var y = year; y >= 2011; y--) {
                for (var m = 12; m > 0; m--) {
                    var mm = Simple.date.transDateString(m);
                    if (anchorDic[y + mm]) {
                        var moveSteps = year - y - 3;
                        if (moveSteps > 0) {
                            move(moveSteps);
                        }
                        refreshLiCore(anchorDic[y + mm]);
                        return;
                    }
                    else {
                        ul.getElementsByTagName("a")[href_idx[y + mm]].className = "future";
                    }
                }
                ul.getElementsByTagName("a")[href_idx[y]].className = "future";
            }
        }
    }
    /**************** 更新时间轴样式相关方法 ****************/

    /**************** 气泡相关方法 ****************/
    function initBubble() {
        var bClose = Simple.cookie.getInner("plugin", "bub");
        var domBub = Simple("bubble");
        // 关闭过或者无初始化月，则说明不需要显示气泡
        if (bClose === "0" || !anchor) {
            domBub.style.visibility = 'hidden';
        }
        else {
            // 不存在此cookie则设置cookie
            if (!bClose) {
                Simple.cookie.setInner("plugin", "bub", "1");
            }
            if (anchor != initMonth) {
                Simple("bubble_wording").innerHTML = "您的功能还在这里";
            }
            var domClose = Simple("bubble_close");
            Simple.e.addEvent(domBub, "mouseover", function () {
                domBub.style.backgroundPosition = '0 -34px';
                domClose.style.visibility = 'visible';
            });

            Simple.e.addEvent(domBub, "mouseout", function () {
                domBub.style.backgroundPosition = '0 0';
                domClose.style.visibility = 'hidden';
            });

            Simple.e.addEvent(domClose, "click", function () {
                domBub.style.visibility = 'hidden';
                Simple.cookie.setInner("plugin", "bub", 0);
                pgvSendClick({ hottag: "R1.JT.IM.PLUGIN_BUBBLE" });
            });
            refreshBubble();
        }
    }

    // 刷新气泡样式：左侧距离
    function refreshBubble() {
        var bClose = Simple.cookie.getInner("plugin", "bub");
        var domBub = Simple("bubble");
        if (anchor && bClose === "1" && (nYearCurrent >= nMove && nYearCurrent <= nMove + 3)) {
            var nLeftParentLi = nYearCurrent - nMove, nLeftChildLi;
            if (nYearCurrent == nYearSelected) {
                nLeftChildLi = nMonthCurrent;
            }
            var left = nLeftParentLi * 59 + (nLeftChildLi ? 59 + nLeftChildLi * 48 + 24 : 29)
                     + (nYearSelected < nYearCurrent ? 576 : 0);
            // 17 + 35 - 66 = -14
            domBub.style.left = left - 14 + "px";
            domBub.style.visibility = 'visible';
        }
        else {
            domBub.style.visibility = 'hidden';
        }
    }
    /**************** 气泡相关方法 ****************/

    /**************** 更新Li相关方法 ****************/
    function refreshLiCore(href) {
        var y = year - nYearSelected;
        var m = Simple.date.transDateString(12 - nMonthSelected);
        // 选中年因左右移被移出时间轴显示区域
        if (nYearSelected < nMove || nYearSelected > nMove + 3) {
            updateLi({ "index": nYearSelected * 13, "href": anchorDic[y] },
                { "index": nYearSelected * 13 + nMonthSelected + 1, "href": anchorDic[y + "" + m] });
            nYearSelected = nMove;
            if (anchorDic[year - nYearSelected]) {
                nMonthSelected = 12 - parseInt(anchorDic[year - nYearSelected].substring(4, 6).replace(/^0/, ""));
            }
            else {
                nMonthSelected = 0;
            }
            updateLi({ "index": nYearSelected * 13 }, { "index": nYearSelected * 13 + nMonthSelected + 1 }, true);
        }
        // 如果href存在
        else if (href) {
            updateLi({ "index": nYearSelected * 13, "href": anchorDic[y] },
            { "index": nYearSelected * 13 + nMonthSelected + 1, "href": anchorDic[y + "" + m] });
            nYearSelected = year - parseInt(href.toString().substring(0, 4));
            nMonthSelected = 12 - parseInt(href.toString().substring(4, 6).replace(/^0/, ""))
            updateLi({ "index": nYearSelected * 13 }, { "index": nYearSelected * 13 + nMonthSelected + 1 }, true);
        }
    }

    function updateLi(yearInfo, monthInfo, bSelected) {
        updateYearLi(yearInfo, bSelected);
        updateMonthLi(monthInfo, bSelected);
    }

    function updateYearLi(yearInfo, bSelected) {
        var yearLink = ul.getElementsByTagName("a")[yearInfo.index];
        if (bSelected) {
            updateClass(yearLink, ["future", "past"], "selected");
            yearLink.parentNode.className = "selected";
            yearLink.removeAttribute("href");
            Simple.e.removeEvent(yearLink, "click", refreshLi);
        }
        else {
            updateClass(yearLink, ["future", "past"], "");
            yearLink.parentNode.className = "";
            if (yearInfo.href) {
                yearLink.href = yearInfo.href;
                Simple.e.addEvent(yearLink, "click", refreshLi);
            }
        }
    }

    function updateMonthLi(monthInfo, bSelected) {
        var monthLink = ul.getElementsByTagName("a")[monthInfo.index];
        if (bSelected) {
            updateClass(monthLink, ["future", "past"], "selected");
            monthLink.removeAttribute("href");
            Simple.e.removeEvent(monthLink, "click", refreshLi);
        }
        else {
            updateClass(monthLink, ["future", "past"], "");
            if (monthInfo.href) {
                monthLink.href = monthInfo.href;
                Simple.e.addEvent(monthLink, "click", refreshLi);
            }
        }
    }

    // 防止某些样式被覆盖
    function updateClass(dom, arrFilterClass, setClass) {
        for (var i = 0, len = arrFilterClass.length; i < len; i++) {
            if (dom.className == arrFilterClass[i]) {
                return;
            }
        }
        dom.className = setClass;
    }
    /**************** 更新Li相关方法 ****************/

    /**************** 加载版本内容相关方法 ****************/
    function requestVersions() {
        var text = '{"ec":0,"info":[{"content":[{"face":"face/friend_icon.png","hasDetail":1,"id":4,"suggest_addr":"http://support.qq.com/cgi-bin/content_new?tid=13149496887476957&num=10&order=0&fid=674&dispn=1&start=0&pn=1&gb=0","summary":"好友资料页新增“与我的故事”；点击好友资料卡左栏“与我的故事”，一道美丽的彩虹会出现在您眼前。","title":"与我的故事"},{"face":"face/appbox_icon.png","hasDetail":1,"id":3,"suggest_addr":"http://support.qq.com/cgi-bin/content_new?tid=13149498084176959&num=10&order=0&fid=674&dispn=1&start=0&pn=1&gb=0","summary":"启动栏最右边图标进入应用管理器，最新应用第一时间获知，一键智能将最常用的应用放到快速启动栏中。","title":"应用管理器"},{"face":"face/handwrite_icon.png","hasDetail":1,"id":2,"suggest_addr":"http://support.qq.com/cgi-bin/content_new?tid=13149495602576830&num=10&order=0&fid=674&dispn=1&start=0&pn=1&gb=0","summary":"除了键盘输入以外，QQ贴心的提供了手写面板和语音的输入，消除输入的障碍，让您打字的速度快速提升。","title":"多功能输入"}],"date":20110907,"type":0},{"content":[{"face":"face/update_icon.png","hasDetail":1,"id":1,"suggest_addr":"http://support.qq.com/cgi-bin/content_new?tid=13149501979446229&num=10&order=0&fid=674&dispn=1&start=0&pn=1&gb=0","summary":"新推出的软件更新优化让您的QQ在线生活恢复色彩，设置为推荐/手动方式，将根据您的需要进行智能升级。","title":"更新优化"}],"date":20110829,"type":1}]}';
        loadVersions(eval("(" + text + ")").info);
    }

    function loadVersions(info) {
        if (info) {
            var dc = document.createDocumentFragment();
            for (var i = 0, len = info.length; i < len; i++) {
                var versionInfo = info[i];
                // 加载容器
                var version = Simple.dom.append("div", { "class": "per_version", "id": versionInfo.date }, null, dc);
                // 加载标题 = 时间 + 更新种类
                var title = Simple.dom.append("div", { "class": "title" }, null, version);
                var date = Simple.date.transform(versionInfo.date, '-');
                Simple.dom.append("span", { "class": "title_date" }, date, title);
                var catelogy = versionInfo.type == "0" ? "功能更新" : "版本更新";
                Simple.dom.append("span", { "class": "title_wording" }, catelogy, title);
                // 加载核心内容 = n个应用
                var core = Simple.dom.append("div", { "class": (i == len - 1 ? "lastBox" : "box") }, null, version);
                var content = versionInfo.content;
                for (var j = 0, inLen = content.length; j < inLen; j++) {
                    var app = content[j];
                    // 应用
                    var appClass = "small_box" + (j % 3 ? " box_margin_left" : "") + (j / 3 >= 1 ? " box_margin_top" : "");
                    var appBox = Simple.dom.append("div", { "class": appClass }, null, core);
                    // 应用标题 = 详细说明图标 + 标题内容
                    var appTitle = Simple.dom.append("div", { "class": "app_title","title":"点击查看功能详细介绍" }, null, appBox);
                    if (app.hasDetail == "1") {
                        Simple.e.addEvent(appTitle, "mouseover", function (appTitle) {
                            return function () {
                                appTitle.className += " focus";
                                appTitle.style.cursor = "pointer";
                            }
                        } (appTitle));
                        Simple.e.addEvent(appTitle, "mouseout", function (appTitle) {
                            return function () {
                                appTitle.className = appTitle.className.replace(" focus", "");
                                appTitle.style.cursor = "default";
                            }
                        } (appTitle));
                        Simple.e.addEvent(appTitle, "click", function (href) {
                            return function () {
                                displayDialog(href);
                            }
                        } (DETAILHREF + app.id));
                    }

                    var appDetailDiv = Simple.dom.append("div", { "class": "app_detail" }, null, appTitle);
                    var appDetail = Simple.dom.append("div", { "class": "app_detail_img" }, null, appDetailDiv);

                    appDetail.style.backgroundImage = "url(" + app.face + ")";
                    Simple.dom.append("span", { "class": "app_title_wording" }, app.title, appTitle);
                    // 简要说明
                    Simple.dom.append("div", { "class": "summary" }, app.summary, appBox);
                    // 交互 = 顶 + 意见
                    var interact = Simple.dom.append("div", { "class": "interact" }, null, appBox);

                    var suggest = Simple.dom.append("div", { "class": "suggest" }, null, interact);
                    var suggestLink = Simple.dom.append("a", { "href": app.suggest_addr, "target": "_blank" }, "反馈", suggest);
                    Simple.e.addEvent(suggestLink, "click", function () {
                        pgvSendClick({ hottag: "R1.JT.IM.PLUGIN_SUGGEST" });
                    });
                }
                updateAnchorDic(versionInfo.date);
            }
            Simple("client_version").appendChild(dc);
        }
        // 再次更新时间轴样式
        CorrectCss();
        // 加载时间轴逻辑
        loadTimeLogic();
        // 设置锚点
        setAnchor(anchor);
    }

    function updateAnchorDic(date) {
        updateYearAnchor(date);
        updateMonthAnchor(date);
    }

    function updateMonthAnchor(date) {
        var m = date.toString().substring(0, 6);
        for (var month in anchorDic) {
            if (month == m) {
                return;
            }
        }
        anchorDic[m] = date;
    }

    function updateYearAnchor(date) {
        var y = date.toString().substring(0, 4);
        for (var year in anchorDic) {
            if (year == y) {
                return;
            }
        }
        anchorDic[y] = date;
    }

    function displayDialog(href) {
        // 去掉滚动条
        document.body.className = "mask_body";
        document.documentElement.className = "mask_html";
        // 弹窗
        var wrapper = Simple("ifrWrapper");
        var cWidth = Simple.client.getClientWidth();
        var cHeight = Simple.client.getClientHeight();
        wrapper.style.width = cWidth + "px";
        wrapper.style.height = cHeight + "px";
        wrapper.style.visibility = "visible";
        var opacity = 0;
        var p = setInterval(function () {
            if (opacity == 50) { clearInterval(p); }
            else if (opacity == 10) {
                opacity += 10;
                parent.Simple("contentIfr").src = href;
                parent.Simple("ifrDiv").style.left = (cWidth - 720) / 2 + "px";
                parent.Simple("ifrDiv").style.top = (cHeight - 600) / 2 + "px";
                parent.Simple("ifrDiv").style.visibility = "visible";
                Simple.e.addEvent(document.body, "keydown", esc);
                Simple.e.addEvent(Simple("plugin_close"), "click", maskQuit);
            }
            else {
                opacity += 10;
                wrapper.style.opacity = opacity / 100; ;
                wrapper.style.filter = "alpha(opacity=" + opacity + ")";
            }
        }, 25);
        pgvSendClick({ hottag: "R1.JT.IM.PLUGIN_PREVIEW" });
        Simple.e.preventDefault(e);
    }

    function esc(e) {
        e = window.event || e;
        if (e.keyCode == 27) {
            maskQuit();
        }
    }
    /**************** 加载版本内容相关方法 ****************/

    /**************** 顶相关方法 ****************/
    function postSupport(event) {
        var src = Simple.e.getSrcElement(event);
        if (src.visited) {
            return;
        }
        src.visited = 1;
        cur_id = src.targetId;
        updateSupport();
        Simple.http.post(SUPPORTHREF, { "id": cur_id });
    }

    function updateSupport() {
        var support = Simple(cur_id + "_support");
        var parent = support.parentNode;
        var supportLink = parent.getElementsByTagName("a")[0];
        Simple.e.removeEvent(supportLink, "click", postSupport);

        var nSupport = parseInt(support.innerHTML);
        var div = Simple.dom.append("div", { "class": "active" }, "+1", parent);
        var opacity = 0;
        var add = 0;
        var nStop = 2;
        var p = setInterval(function () {
            add += 10;
            if (add > 100) {
                opacity -= 10;
            }
            else {
                opacity += 10;
            }
            if (opacity === 100 && --nStop) {
                return;
            }
            div.style.opacity = opacity / 100;
            div.style.filter = "alpha(opacity=" + opacity + ")";
            if (opacity === 0) {
                clearInterval(p);
                support.innerHTML = nSupport + 1;
                parent.removeChild(div);
                opacity = 100;
                var q = setInterval(function () {
                    opacity -= 10;
                    supportLink.style.opacity = opacity / 100;
                    supportLink.style.filter = "alpha(opacity=" + opacity + ")";
                    if (opacity === 50) {
                        supportLink.style.backgroundPosition = "0 -15px";
                        supportLink.style.opacity = 1.0;
                        supportLink.style.filter = "alpha(opacity=100)";
                        supportLink.style.cursor = "default";
                        clearInterval(q);
                    }
                }, 25)
            }
        }, 50);
    }
    /**************** 顶相关方法 ****************/

    /**************** 时间轴逻辑相关方法 ****************/
    function loadTimeLogic() {
        for (var href in href_idx) {
            var link = ul.getElementsByTagName("a")[href_idx[href]];
            if (href.length == 4) {
                // 年对应锚点为最新月锚点
                if (href > 2010) {
                    if (anchorDic[href] && link.className != "selected") {
                        link.href = anchorDic[href];
                        Simple.e.addEvent(link, "click", refreshLi);
                    }
                    Simple.e.addEvent(link, "mouseover", function (event) {
                        var src = Simple.e.getSrcElement(event);
                        updateClass(src, ["selected", "past", "future"], "cover");
                    });
                    Simple.e.addEvent(link, "mouseout", function (event) {
                        var src = Simple.e.getSrcElement(event);
                        updateClass(src, ["selected", "past", "future"], "");
                    });
                }
            }
            else {
                if (anchorDic[href] && link.className != "selected") {
                    link.href = anchorDic[href];
                    Simple.e.addEvent(link, "click", refreshLi);
                }
                Simple.e.addEvent(link, "mouseover", function (event) {
                    var src = Simple.e.getSrcElement(event);
                    updateClass(src, ["selected", "past", "future"], "cover");
                });
                Simple.e.addEvent(link, "mouseout", function (event) {
                    var src = Simple.e.getSrcElement(event);
                    updateClass(src, ["selected", "past", "future"], "");
                });
            }
        }
    }

    function refreshLi(event) {
        var src = Simple.e.getSrcElement(event);
        var href = src.href.match(/\d{8}/)[0];
        refreshLiCore(href);
        setAnchor(href);
        pgvSendClick({ hottag: "R1.JT.IM.PLUGIN_MONTH_" + href.substring(0, 6) });
        Simple.e.preventDefault(event);
    }

    function setAnchor(href) {
        if (href) {
            var height = Simple("plugin_header").offsetHeight;
            var toTop = Simple.client.getPos(Simple(href))[1];
            if (typeof isIE6 === "undefined") {
                isIE6 = /MSIE 6.0/i.test(navigator.userAgent) && (typeof window.opera == "undefined");
            }
            if (isIE6) {
                document.body.scrollTop = toTop - height;
            }
            else {
                window.scrollTo(0, toTop - height);
            }
        }
    }
    /**************** 时间轴逻辑相关方法 ****************/

    /**************** 主方法 ****************/
    function loadContent() {
        // 加载时间轴内容
        loadTimeHTML();
        // 初始化显示版本
        initVersion();
        // 加载时间轴样式
        loadTimeCss();
        // 初始化气泡
        initBubble();
        // 请求版本内容，触发加载版本内容+加载时间轴事件
        requestVersions();
    }
    /**************** 主方法 ****************/

    /**************** 初始执行 ****************/
    // ul中a计数，控制a索引
    var aCount = 0;
    // id及a索引 匹配字典，月对应锚字典
    var href_idx = {}, anchorDic = {};
    // 顶对应的id号
    var cur_id;
    // 当前时间
    var date = new Date();
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    // 跳转到的锚点，初始化显示更新月
    var anchor = "", initMonth = "" + year + Simple.date.transDateString(month);
    // 时间轴移动数，时间轴总移动数
    var nMove = 0, nTotal = year - 2011;
    // 当前选择年索引，当前选择月索引，当前更新版本年索引，当前更新版本月索引
    var nYearSelected = 0, nMonthSelected = 0, nYearCurrent = 0, nMonthCurrent = 0;
    // 时间轴ul
    var ul = Simple("time_nav");
    // 详细信息、顶基地址
    var DETAILHREF = "plugin_detail.shtml?id=";
    var SUPPORTHREF = "cgi-bin/support";

    modifyFont();
    // 加载主体
    loadContent();
    tcss();
    /**************** 初始执行 ****************/
})();

function maskQuit() {
    var opacity = 50;
    var p = setInterval(function () {
        if (opacity == 0) {
            clearInterval(p);
            Simple("ifrWrapper").style.visibility = "hidden";
            Simple("contentIfr").style.height = "545px";
            Simple("main").style.height = "545px";
            Simple("contentIfr").contentWindow.document.getElementById("content").innerHTML = "";
            document.body.className = "";
            document.documentElement.className = "";
        }
        else if (opacity == 10) {
            opacity -= 10;
            Simple("ifrDiv").style.visibility = "hidden";
        }
        else {
            opacity -= 10;
            Simple("ifrWrapper").style.opacity = opacity / 100; ;
            Simple("ifrWrapper").style.filter = "alpha(opacity=" + opacity + ")";
        }
    }, 25);
}

function modifyFont() {
    // 非IE6修改字体为雅黑
    var os = navigator.userAgent.toUpperCase();
    if (os.indexOf('NT 6.') > -1) {
        document.write('<style type="text/css">body {font-family: 微软雅黑,Tahoma,Verdana,Arial,Helvetica,sans-serif;}</style>');
    }
}

function tcss() {
    Simple.http.loadScript("http://pingjs.qq.com/tcss.ping.js", function () {
        pgvMain('', { virtualURL: '/update/index.shtml' });
    });
}