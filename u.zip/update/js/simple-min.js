﻿
var Simple = window.Simple = function (n) {
    return typeof (n) == "string" ? document.getElementById(n) : n;
};

Simple.http = {
    getXHR: function () {
        return window.ActiveXObject ? new ActiveXObject("Microsoft.XMLHTTP") : new XMLHttpRequest();
    },

    ajax: function (url, para, cb, method, type) {
        var xhr = Simple.http.getXHR();
        xhr.open(method, url);
        if (typeof cb === "function") {
            xhr.onreadystatechange = function () {
                if (xhr.readyState == 4) {
                    if ((xhr.status >= 200 && xhr.status < 300) || xhr.status === 304 || xhr.status === 1223 || xhr.status === 0) {
                        if (typeof (type) == "undefined") {
                            cb(eval("(" + xhr.responseText + ")"));
                        } else {
                            cb(xhr.responseText);
                        }
                    }
                }
            }
        }
        xhr.send(para);
    },

    get: function (url, para, cb, type) {
        var s = "";
        for (var i in para) {
            s += "&" + i + "=" + para[i];
        }
        if (url.indexOf("?") == -1) {
            url += "?";
        }
        url += s;
        // 加时间戳
        url += "&t=" + (new Date().getTime());
        Simple.http.ajax(url, null, cb, "GET", type);
    },

    post: function (url, para, cb, type) {
        var s = "";
        for (var i in para) {
            s += "&" + i + "=" + para[i];
        }
        Simple.http.ajax(url, s, cb, "POST", type);
    },

    loadScript:function (src, callback) {   
		var tag = document.createElement("script");   
		if(callback){
			tag.onload = tag.onreadystatechange = function() {
				if ( !this.readyState ||this.readyState === "loaded" || this.readyState === "complete") {
					callback();
					tag.onload = tag.onreadystatechange = null;
					if (tag.parentNode ) {
						tag.parentNode.removeChild( tag );
					}
				}
			};			
		} 
		
		tag.src = src;   
		document.getElementsByTagName("head")[0].appendChild(tag);   
	}
};

Simple.e = {
    addEvent: function (oTarget, sEventType, fnHandler) {
        if (oTarget.addEventListener) {
            oTarget.addEventListener(sEventType, fnHandler, false);
        } else if (oTarget.attachEvent) {
            oTarget.attachEvent("on" + sEventType, fnHandler);
        } else {
            oTarget["on" + sEventType] = fnHandler;
        }
    },
    removeEvent: function (oTarget, sEventType, fnHandler) {
        if (oTarget.removeEventListener) {
            oTarget.removeEventListener(sEventType, fnHandler, false);
        } else if (oTarget.detachEvent) {
            oTarget.detachEvent('on' + sEventType, fnHandler);
        } else {
            oTarget['on' + sEventType] = null;
        }
    },

    getSrcElement: function (event) {
        return event.target ? event.target : window.event.srcElement;
    },

    preventDefault: function (e) {
        var e = e || window.event;
        e.preventDefault ? e.preventDefault() : e.returnValue = false;
    },

    stopPropagation: function (e) {
        if (e && e.stopPropagation) {
            e.stopPropagation();
        }
        else {
            window.event.cancelBubble = true;
        }
    }
}

Simple.cookie = {
    get: function (n) {
        var m = document.cookie.match(new RegExp("(^| )" + n + "=([^;]*)(;|$)"));
        return !m ? "" : unescape(m[2]);
    },
    set: function (name, value, domain, path, hour) {
        var expire = new Date();
        expire.setTime(expire.getTime() + (hour ? 3600000 * hour : 30 * 60 * 1000));
        document.cookie = name + "=" + value + "; " + "expires=" + expire.toGMTString() + "; path=" + (path ? path : "/") + "; " + (domain ? ("domain=" + domain + ";") : "");
    },
    getInner: function (n, nn) {
        var m = this.get(n);
        if (!m) return;
        var mm = unescape(m).match(new RegExp("(^|,)" + nn + "=([^;]*?)(,|$)"));
        return !mm ? "" : mm[2];
    },
    setInner: function (n, nn, value, domain, path, hour) {
        var c = this.get(n);
        var cc = this.getInner(n, nn);
        if (!c) { value = nn + "=" + value; }
        else if (!cc) { value = c + "," + nn + "=" + value; }
        else { value = c.replace(new RegExp(nn + "=[^,]*"), nn + "=" + value) }
        this.set(n, value, domain, path, hour);
    }
};

Simple.query = function (href, n) {
    var m = href.match(new RegExp("(/?|&)" + n + "=([^&]*)(&|$)"));
    return !m ? "" : unescape(m[2]);
};
Simple.client = {
    getDocEle: function () {
        return document.compatMode == 'CSS1Compat' ? document.documentElement : document.body;
    },
    getPos: function (parentObj) {
        var parentPos = [];
        parentPos[0] = parentObj.offsetLeft;
        parentPos[1] = parentObj.offsetTop;
        while (parentObj = parentObj.offsetParent) {
            parentPos[0] += parentObj.offsetLeft;
            parentPos[1] += parentObj.offsetTop;
        }
        return parentPos;
    },
    getScrollWidth: function () { return this.getDocEle().scrollWidth; },
    getScrollHeight: function () { return this.getDocEle().scrollHeight; },
    getScrollLeft: function () { return document.documentElement.scrollLeft || document.body.scrollLeft || 0 },
    getScrollTop: function () { return document.documentElement.scrollTop || document.body.scrollTop || 0 },
    getClientWidth: function () { return this.getDocEle().clientWidth; },
    getClientHeight: function () { return this.getDocEle().clientHeight; }
}

Simple.date = {
    getCurrent: function () { return { year: (new Date()).getFullYear(), month: (new Date()).getMonth() + 1, day: (new Date()).getDate()} },
    getDays: function (year, month) {
        if (isNaN(year)) { return; }
        if (month < 1 || month > 12) { return; }
        var mDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0)) { mDays[1] = 29; }
        return [month - 1];
    },

    getTimeSpan: function (year, month) {
        var y, m, days;
        if (arguments.length == 0) {
            var cur = this.getCurrent();
            days = this.getDays(cur.year, cur.month);
        }
        else if (arguments.length == 1) {
            if (isNaN(year)) { return; }
            y = year;
            days = 31;
        }
        else {
            if (isNaN(year)) { return; }
            y = year;
            if (month < 1 || month > 12) { return; }
            m = month;
        }
        return { "begin": this.toString(y, m ? m : 1, 1), "end": this.toString(y, m ? m : 12, days) };
    },

    toString: function (year, month, day) {
        return year + this.transDateString(month) + (day < 10 ? "0" + day : day);
    },

    transform: function (sDate, char) {
        var sDate = sDate.toString();
        return sDate.substring(0, 4) + char + sDate.substring(4, 6) + char + sDate.substring(6, 8);
    },

    transDateString: function (m) {
        return m < 10 ? "0" + m : m.toString();
    }
};

Simple.dom = {
    append: function (element, property, innerText, domParent) {
        var dom = document.createElement(element);
        for (var p in property) {
            // IE6、IE7不支持setAttribute("class", para);
            if (p == "class") { dom.className = property[p]; }
            else { dom.setAttribute(p, property[p]); }
        }
        if (typeof innerText !== "undefined" && innerText !== null && innerText !== "") {
            this.appendText(innerText, dom);
        }
        if (domParent) { domParent.appendChild(dom); }
        return dom;
    },

    appendText: function (text, domParent) {
        var dom = document.createTextNode(Simple.string.HTMLDeCode(text));
        if (domParent) { domParent.appendChild(dom); }
        return dom;
    }
}

Simple.math = {
    sgn: function (n) {
        return n > 0 ? 1 : -1;
    }
}

Simple.string = {
    isJsonString: function (testStr) {
        var strLen = testStr.length;
        return (testStr.charAt(0) == '{' && testStr.charAt(strLen - 1) == '}')
		    || (testStr.charAt(0) == '[' && testStr.charAt(strLen - 1) == ']');
    },

    // 去除字符串首尾空白字符
    removeSideSpace: function (str) {
        return str.replace(/(^\s*)|(\s*$)/g, "");
    },

    // 双字节字取3个长度
    toChar: function (str) {
        return str.replace(/[^\x00-\xff]/g, "***");
    },

    // 检测图片后缀jpg、png、gif
    isImgPattern: function (str) {
        return /(jpgSimple)|(pngSimple)|(gifSimple)/ig.test(str);
    },

    // 隔段转行，如果只显示几行，则末尾添加......
    lineLimit: function (str, num, cutLine) {
        if (str == "")
            return "";
        var lines = Math.ceil(str.length / num);
        var ret = "";
        var bCut = typeof cutLine == "undefined";
        var len = bCut ? lines : cutLine;
        for (var i = 1, index = 0; i < len; i++, index += num) {
            ret += str.substring(index, index + num) + "<br />";
        }
        if (bCut) {
            return ret + str.substring(index, str.length);
        }
        else {
            return ret + str.substring(index, cutLine * num - 1) + "...";
        }
    },
    HTMLDeCode: function (str) {
        var s = str.toString();
        if (s.length == 0) return "";
        s = s.replace(/&amp;/g, "&")
				.replace(/&lt;/g, "<")
				.replace(/&gt;/g, ">")
				.replace(/&nbsp;/g, " ")
                .replace(/&#160;/g, " ")
				.replace(/&apos;/g, "'")
                .replace(/&#39;/g, "'")
                .replace(/&#92;/g, "\\")
				.replace(/&quot;/g, "\"");
        return s;
    },

    ellipsis: function (str, len) {
        var temp = str.replace(/[^\x00-\xff]/g, "**");
        if (len < temp.length) {
            var end = temp.substring(0, len - 3) + "...";
        } else {
            var end = str;
        }
        return end;
    }
}