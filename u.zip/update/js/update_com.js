﻿window.$$ = function (n) {
    return typeof (n) == "string" ? document.getElementById(n) : n;
};
$$.client = {
    getDocEle:function () {
        return document.compatMode == 'CSS1Compat' ? document.documentElement : document.body;
    },
    getPos:function (parentObj) {
        var parentPos = [];
        parentPos[0] = parentObj.offsetLeft;
        parentPos[1] = parentObj.offsetTop;
        while (parentObj = parentObj.offsetParent) {
            parentPos[0] += parentObj.offsetLeft;
            parentPos[1] += parentObj.offsetTop;
        }
        return parentPos;
    },
    getScrollWidth:function () {
        return this.getDocEle().scrollWidth;
    },
    getScrollHeight:function () {
        return this.getDocEle().scrollHeight;
    },
    getScrollLeft:function () {
        return document.documentElement.scrollLeft || document.body.scrollLeft || 0
    },
    getScrollTop:function () {
        return document.documentElement.scrollTop || document.body.scrollTop || 0
    },
    getClientWidth:function () {
        return this.getDocEle().clientWidth;
    },
    getClientHeight:function () {
        return this.getDocEle().clientHeight;
    }
}
$$.e = {
    addEvent:function (oTarget, sEventType, fnHandler) {
        if (oTarget.addEventListener) {
            oTarget.addEventListener(sEventType, fnHandler, false);
        } else if (oTarget.attachEvent) {
            oTarget.attachEvent("on" + sEventType, fnHandler);
        } else {
            oTarget["on" + sEventType] = fnHandler;
        }
    }
}

document.domain = "qq.com";
$$("pluginIfr").src = "http://cgi.im.qq.com/plugin/index.shtml" + window.location.search;
sidesResize();
function sidesResize() {
    var sLeft = $$.client.getScrollLeft();
    var left = Math.floor(($$.client.getClientWidth() - 910 - 16) / 2)  - sLeft;
    var width = $$.client.getClientWidth();
    if (left < 0) {
        left = 0;
        width = width - 16;
        $$("comHeader").style.width = width + "px";
        $$("comFooter").style.width = width + "px";
    }
    else {
        width = width >= 910 ? 910 : width;
        $$("comHeader").style.width = width + "px";
        $$("comFooter").style.width = width + "px";
    }
    $$("comHeader").style.left = left + "px";
    $$("comFooter").style.left = left + "px";
}

function initFooter(sHeight, cHeight, sTop) {
    var diff = sHeight - cHeight - sTop;
    var height = diff > 73 ? 0 : (73 - diff);
    height > 73 ? height = 73 : 0;
    $$("comFooter").style.height = height + "px";
}

function sidesScroll(sLeft) {
    if (sLeft == 0) {
        return;
    }
    var cWidth = $$.client.getClientWidth() - 17;
    $$("comHeader").style.width = cWidth + sLeft + "px";
    $$("comFooter").style.width = cWidth + sLeft + "px";
    $$("comHeader").style.left = -sLeft + "px";
    $$("comFooter").style.left = -sLeft + "px";
}

function setIfr() {
    if ($$("ifrWrapper").style.visibility == "visible" && $$("ifrDiv").style.visibility == "visible") {
        var h = $$("ifrDiv").offsetHeight;
        var w = $$("ifrDiv").offsetWidth;
        var cWidth = $$.client.getClientWidth();
        var cHeight = $$.client.getClientHeight();
        var left = (cWidth - w) / 2;
        var top = (cHeight - h) / 2;
        $$("ifrDiv").style.top = top + "px";
        $$("ifrDiv").style.left = left + "px";
        $$("ifrWrapper").style.height = cHeight + "px";
        $$("ifrWrapper").style.width = cWidth + "px";
    }
}

function displayDialog(href) {
    var wrapper = $$("ifrWrapper");
    var cWidth = $$.client.getClientWidth();
    var cHeight = $$.client.getClientHeight();
    wrapper.style.width = cWidth + "px";
    wrapper.style.height = cHeight + "px";
    wrapper.style.visibility = "visible";
    var opacity = 0;
    var p = setInterval(function () {
        if (opacity == 50) {
            clearInterval(p);
        }
        else if (opacity == 10) {
            opacity += 10;
            $$("contentIfr").src = href;
            $$("ifrDiv").style.left = (cWidth - 720) / 2 + "px";
            $$("ifrDiv").style.top = (cHeight - 600) / 2 + "px";
            $$("ifrDiv").style.visibility = "visible";
            $$.e.addEvent(document.body, "keydown", esc);
            $$.e.addEvent(window.frames[0].document.body, "keydown", esc);
            $$.e.addEvent($$("plugin_close"), "click", maskQuit);
        }
        else {
            opacity += 10;
            wrapper.style.opacity = opacity / 100;
            ;
            wrapper.style.filter = "alpha(opacity=" + opacity + ")";
        }
    }, 25);
}

function maskQuit() {
    var opacity = 50;
    var p = setInterval(function () {
        if (opacity == 0) {
            clearInterval(p);
            $$("ifrWrapper").style.visibility = "hidden";
            $$("ifrWrapper").style.height = "545px";
            $$("main").style.height = "545px";
            $$("contentIfr").contentWindow.document.getElementById("content").innerHTML = "";
        }
        else if (opacity == 10) {
            opacity -= 10;
            $$("ifrDiv").style.visibility = "hidden";
        }
        else {
            opacity -= 10;
            $$("ifrWrapper").style.opacity = opacity / 100;
            $$("ifrWrapper").style.filter = "alpha(opacity=" + opacity + ")";
        }
    }, 25);
}

function esc(e) {
    e = window.event || e;
    if (e.keyCode == 27) {
        maskQuit();
    }
}

/* $$("pluginIfr"). */
function displayPrompt() {
    $$("windows").style.display = "block";
    var wrapper = $$("ifrWrapper");
    var cWidth = $$.client.getClientWidth();
    var cHeight = $$.client.getClientHeight();
    wrapper.style.width = cWidth + "px";
    wrapper.style.height = cHeight + "px";
    wrapper.style.visibility = "visible";
    var opacity = 0;
    var p = setInterval(function () {
        if (opacity == 50) {
            clearInterval(p);
        }
        else if (opacity == 10) {
            opacity += 10;
            $$.e.addEvent(document.body, "keydown", esc2);
            $$.e.addEvent(window.frames[0].document.body, "keydown", esc2);
        }
        else {
            opacity += 10;
            wrapper.style.opacity = opacity / 100;
            ;
            wrapper.style.filter = "alpha(opacity=" + opacity + ")";
        }
    }, 25);
}

$$.e.addEvent($$("closeDiv"), "click", maskQuit2);

function maskQuit2() {
    $$("windows").style.display = "none";
    var opacity = 50;
    var p = setInterval(function () {
        if (opacity == 0) {
            clearInterval(p);
            $$("ifrWrapper").style.visibility = "hidden";
            $$("ifrWrapper").style.height = "545px";
        }
        else if (opacity == 10) {
            opacity -= 10;
        }
        else {
            opacity -= 10;
            $$("ifrWrapper").style.opacity = opacity / 100;
            $$("ifrWrapper").style.filter = "alpha(opacity=" + opacity + ")";
        }
    }, 25);
}
function esc2(e) {
    e = window.event || e;
    if (e.keyCode == 27) {
        maskQuit2();
    }
}