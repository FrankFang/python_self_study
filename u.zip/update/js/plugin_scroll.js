var BACK_NODE_WIDTH = 54;
var BACK_NODE_HEIGHT = 35;
var FOOT_HEIGHT = 73;
var WIDTH = 910;
document.write('<a id="backToTop" onclick="return toTop(this);" style="right: '+getRightPos()+'px;position: fixed!important;_position: absolute;" href="#"></a>');
if (typeof isIE6 === "undefined") {
    isIE6 = /MSIE 6.0/i.test(navigator.userAgent) && (typeof window.opera == "undefined");
}
function toTop(obj) {
    if (isIE6) { window.document.body.scrollTop = 0; }
    else { window.scrollTo(0, 0); }
    obj.style.visibility = 'hidden';
    pgvSendClick({ hottag: "R1.JT.IM.PLUGIN_TOTOP" });
    return false;
}
Simple.e.addEvent(window, "scroll", handleScroll);
Simple.e.addEvent(window, "resize", handleResize);

function handleScroll() {
    // ���õ�����
    setToTop();
	// ����ͷλ��
    headerScroll();
}

function handleResize() {
    // ��������Ӧ����
    setIfr();
    // ����ͷλ��
    headerResize();
}

function headerScroll() {
    var sLeft = Simple.client.getScrollLeft();
    if (sLeft == 0) { return; }
    Simple("plugin_header").getElementsByTagName("div")[0].style.left = -sLeft + "px";
}

function headerResize() {
    var sLeft = Simple.client.getScrollLeft();
    if (sLeft == 0 && Simple("plugin_header").getElementsByTagName("div")[0].style.left == "") { return; }
    var left = (Simple.client.getClientWidth() - 910) / 2 - sLeft;
    if (left < 0) { left = 0; }
    Simple("plugin_header").getElementsByTagName("div")[0].style.left = left - sLeft + "px";
}

function setIfr() {
    if (Simple("ifrWrapper").style.visibility == "visible" && Simple("ifrDiv").style.visibility == "visible") {
        var h = Simple("ifrDiv").offsetHeight;
        var w = Simple("ifrDiv").offsetWidth;
        var cWidth = Simple.client.getClientWidth();
        var cHeight = Simple.client.getClientHeight();
        var left = (cWidth - w) / 2;
        var top = (cHeight - h) / 2;
        Simple("ifrDiv").style.top = top + "px";
        Simple("ifrDiv").style.left = left + "px";
        Simple("ifrWrapper").style.height = cHeight + "px";
        Simple("ifrWrapper").style.width = cWidth + "px";
    }
}

function setToTop() {
    var node = document.getElementById('backToTop');
    if (!node) { return; }
    if (Simple.client.getScrollTop()) { setPos(node); node.style.visibility = 'visible'; }
    else { node.style.visibility = 'hidden'; }
}

function setPos(node) {
	if (node.style.position != 'absolute') {
		node.style.bottom = getDisFromBottom() + 'px';
		node.style.right = getRightPos() + 'px';
		return;
	}
	node.style.top = getTopPos() + 'px';
	node.style.left = getLeftPos() + 'px';
}

function getRightPos() {
    var rp = (Simple.client.getClientWidth() - WIDTH) / 2 - BACK_NODE_WIDTH;
	return rp > 0 ? rp : 0;
}

function getLeftPos() {
    var rd = (Simple.client.getClientWidth() - WIDTH) / 2;
    rd = Math.max(rd, 0) + WIDTH;
    return Math.min(Simple.client.getClientWidth() + Simple.client.getScrollLeft() - BACK_NODE_WIDTH, rd);
}

function getTopPos() {
    var topHeight = Simple("plugin_header").offsetHeight;
    var height = Simple("client_version").offsetHeight;
    var scrollHeight = topHeight + height + FOOT_HEIGHT;
    var scrollTop = Simple.client.getScrollTop();
    var clientHeight = Simple.client.getClientHeight();
    if (scrollHeight - scrollTop - clientHeight <= FOOT_HEIGHT) {
        return scrollHeight - scrollTop - FOOT_HEIGHT - BACK_NODE_HEIGHT;
    }
    return clientHeight - BACK_NODE_HEIGHT;
}

function getDisFromBottom() {
    var dis = Simple.client.getScrollTop() + Simple.client.getClientHeight() + FOOT_HEIGHT - Simple.client.getScrollHeight();
	return  dis > 0 ? dis : 0;
}